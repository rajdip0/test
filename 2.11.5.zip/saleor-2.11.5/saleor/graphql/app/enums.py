from ...app.types import AppType
from ..core.enums import to_enum

AppTypeEnum = to_enum(AppType)
